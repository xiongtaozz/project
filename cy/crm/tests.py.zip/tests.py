# -*- coding: utf-8 -*-

# Create your tests here.
import random
from tkinter import *
import tkinter.simpledialog as dl
import tkinter.messagebox as mb
a=random.randint(10,20)

root = Tk()
w=Label(root,text='猜数字play') #创建一个标签
w.pack()  #自动调节大小

mb.showinfo("welcome","欢迎猜数字") #弹出框


while True:
    guess=dl.askinteger("num","please entyr")
    #guess=input("please entry int:")
    if guess==a:
        #print('ok,你猜对了')
        mb.showinfo("welcome","ok,你猜对了")
        break
    elif guess<10:
        #print("你猜的小了，不在范围内")
        mb.showinfo("welcome","你猜的小了，不在范围内")
    elif guess>20:
        #print("你猜的大了，不在范围内")
        mb.showinfo("welcome","你猜的大了，不在范围内")
    elif guess>10 & guess<20:
        #print("你猜的不对，答案范围为10～20之间")
        mb.showinfo("welcome","你猜的不对，答案范围为10～20之间")


