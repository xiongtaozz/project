# -*- coding: utf-8 -*-
import datetime
list=['exit','quit']
def read():
    n=open('record.log','r')
    for i in n:
        print(i)
def wr(txt):
    f=open('record.log','a')
    now = datetime.datetime.now()
    nowdate=now.strftime("%Y-%m-%d %H:%M:%S")
    try:
        f.write(str(txt)+'--- '+str(nowdate)+'\n')
    except ValueError:
        print('entty error!')
    f.close()
while True:
    txt=raw_input('please entyr:')
    if txt in list:
        break
    else:
        wr(txt)
        open('record.log','r')
        read()






