# coding:utf-8


from Tkinter import *
import Tkinter.Simpledialog as dl
import Tkinter.Messagebox as mb

root = Tk()
w = Label(root,text = "Label Title")
w.pack()

mb.showinfo(u"欢迎",u"欢迎来到我的小游戏")
a = dl.askinteger(u"猜数字",u"请输入")

output = u"结果出来了"
mb.showinfo(u"结果;",output)