from django.contrib import admin
from index.models import *
# Register your models here.

admin.site.register(Tag)
admin.site.register(Product)